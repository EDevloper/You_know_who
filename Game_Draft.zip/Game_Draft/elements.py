# -*- coding: utf-8 -*-
"""
Created on Sun Dec  5 16:56:27 2021

@author: jacob
"""

import pygame
import time # for creating timer

from data import *
from sprites import *

class Gamemap:
    def __init__(self):
        self.component_index=0
        for row in range(1,len(GAMEMAP)-1):
            for column in range(1,len(GAMEMAP[row])-1):
                Floor(column-X_SHIFT,row-Y_SHIFT)
                if GAMEMAP[row][column]=="P":
                    Player(column-X_SHIFT+0.6,row-Y_SHIFT) # +0.5 to get player centered
                elif GAMEMAP[row][column]=="C":
                    Component(column-X_SHIFT,row-Y_SHIFT,NAME_LIST[self.component_index],PRICE_LIST[self.component_index],VALUE_LIST[self.component_index])
                    self.component_index+=1
                elif GAMEMAP[row][column]!=".":
                    index=GAMEMAP[row][column]
                    Wall(column-SHIFTS[index][0],row-SHIFTS[index][1],index)
        
        Wall(0-X_SHIFT,0-Y_SHIFT,0)
        Wall(len(GAMEMAP[0])-1-X_SHIFT,0-Y_SHIFT,3)
        Wall(0-X_SHIFT,len(GAMEMAP)-1-Y_SHIFT,4)
        Wall(len(GAMEMAP[0])-1-X_SHIFT,len(GAMEMAP)-1-Y_SHIFT,7)
        for i in range(1,len(GAMEMAP[0])-1):     
              Wall(i-X_SHIFT,len(GAMEMAP)-1-Y_SHIFT,6)
              Wall(i-X_SHIFT,0-Y_SHIFT,1)
        # to account for non-square grids
        for i in range(1,len(GAMEMAP)-1):
            Wall(len(GAMEMAP[0])-1-X_SHIFT,i-Y_SHIFT,5) 
            Wall(0-X_SHIFT,i-Y_SHIFT,2)
        
        # doorway
        Wall(14-X_SHIFT,0-Y_SHIFT,8)
        Wall(15-X_SHIFT,0-Y_SHIFT,9)
        
class Timer():
    def __init__(self):
        self.time_limit=300
        self.start_time=time.time()
        self.elapsed_time=0
        self.remaining_time=self.time_limit-self.elapsed_time
        self.font=pygame.font.Font(None,40)
                
        
    def display(self):
        self.elapsed_time=time.time()-self.start_time
        self.remaining_time=self.time_limit-int(self.elapsed_time)
        self.minutes=self.remaining_time//60
        self.seconds=self.remaining_time%60
        self.countdown=self.font.render(f"{self.minutes} min {self.seconds} sec",False,'Blue')
        screen.blit(self.countdown,(0,0))
        if self.remaining_time==0:
            pygame.quit()
            sys.exit()

