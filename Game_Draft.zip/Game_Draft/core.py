# -*- coding: utf-8 -*-
"""
Created on Wed Dec  1 22:27:10 2021

@author: jacob
"""

# Reference: https://www.youtube.com/watch?v=crUF36OkGDw&ab_channel=ShawCode
# used as inspiration for setting up the game map and core movement mechanics

# Reference: https://www.youtube.com/watch?v=AY9MnQ4x3zk&ab_channel=ClearCode
# used for initialising game screen and quitting

# https://www.youtube.com/watch?v=hDu8mcAlY4E&ab_channel=ClearCode
# For understanding sprites


import pygame # load pygame library
import sys # useful

from data import * # import values of variables set in data.py
from sprites import * # import our game classes from classes.py
from elements import *

        
    
pygame.init() # starts the pygame engine
screen=pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT)) # creates the screen that our game will be displayed on
pygame.display.set_caption('You Know Who') # displays the title of our game
clock=pygame.time.Clock()

g=Gamemap() # generate an object of class gamemap
t=Timer()

while True: # Keep game running forever until we exit this loop: this is the 'game loop'
    for event in pygame.event.get(): # the 'event loop': checks through all the pygame events
        if event.type == pygame.QUIT: # if you click the exit button
            pygame.quit() # the opposite to pygame.init(), closes the pygame engine
            sys.exit() # method from the 'sys' library - securely breaks out of both the for and while loops (not sure why a double 'break' statement fails?) (apparantly more secure than 'break')
    
    screen.fill((0,0,0))
    floors.draw(screen) # this will look for the image and rect (i.e. position) in all of our sprites and draw these onto the screen
    walls.draw(screen)
    components.draw(screen)
    characters.draw(screen)
    t.display()
    sprites.update() # this will look for the 'update' method in all the sprites that we have defined and run it
    pygame.display.update() # refresh the screen so that changes are visually displayed
    clock.tick(FPS) # tells pygame that game should not run faster than 60 FPS, a minimum frame rate is not needed because almost all modern computers can handle basic games at 60 FPS