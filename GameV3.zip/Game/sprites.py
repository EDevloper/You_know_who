# -*- coding: utf-8 -*-
"""
Created on Wed Dec  1 22:29:26 2021

@author: jacob
"""

import pygame
import random

from data import *

pygame.init() # starts the pygame engine
screen=pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT)) # creates the screen that our game will be displayed on



player_spritesheet=pygame.image.load("graphics/main.png").convert() # load player spritesheet and use convert() to import more efficiently
player_spritesheet=pygame.transform.scale(player_spritesheet,(144,192)) # make it 64 by 64 pixels rather than 32 by 32


object_spritesheet=pygame.image.load("graphics/objects.png").convert()


sprites=pygame.sprite.Group() # Not quite sure about this, but apparantly allows us to have one group of sprites with different layer attrtibutes that we can update all at once
walls=pygame.sprite.Group() # Again, not quite sure, but this should allow us to store all our wall objects in a separate group
floors=pygame.sprite.Group()
characters=pygame.sprite.Group()
components=pygame.sprite.Group()
bullets=pygame.sprite.Group()


class Player(pygame.sprite.Sprite): # inherit from the sprite class to make our main character a sprite
    def __init__(self,x,y):
        super().__init__(sprites,characters) # makes player class a sprite and adds it to the sprites list
        #sprites.change_layer(self,PLAYER_LAYER) # sets the layer of the player class
        #pygame.sprite.Sprite.__init__(self,sprites) # add the player sprite to the group of all sprites so that the player can be updated and drawn correctly
        
        self.width=48 # we want the player to be exactly one 48 pixel tile squared in size
        self.height=48
        self.x=TILE_SIZE*x # we want to measure the x and y coordinates in tiles not in pixels, so we need to modify our x in tiles to represent pixels correctly
        self.y=TILE_SIZE*y
        
        # note that you HAVE to call your surface 'image' for the 'blit' method to recognise what you are trying to do
        
        self.facing="down"
        self.pos=[48,0]
        self.count=0
        # make player a little smaller than 64 by 64 surface (choose 60) so that he can fit through tight spaces
        self.image=pygame.Surface([self.width,self.height]) # create a blank surface with area equal to TILE_SIZE
        self.image.set_colorkey((0,0,0)) # make any pixels in the player picture that are pure black
        self.image.blit(player_spritesheet,(0,0),(self.pos[0],self.pos[1],48,48)) # Not quite sure why you need to pass (0,0) here?
        # I think you need to pass (0,0) to tell 'blit' that you want to start reading player_spritesheet from the top left, 
        
        # # Size and visual of player
        # self.image=pygame.Surface([self.width,self.height])
        # self.image.fill((255,0,0))
        
        # Position of player
        self.rect=self.image.get_rect()
        self.rect.x=self.x # insert x and y as rect attributes so that they can be easily accessed and used in rect methods
        self.rect.y=self.y
        
        # For text
        self.font=pygame.font.Font(None,40)
        
        # For the wallet
        self.balance=2000
        
        # For the score
        self.points=0
        
        # For what you have picked up
        
        self.basket=[]
        
        
        self.trigger=0
        
    def update(self): # This update method will run when we call the sprites.update() in the main program
        self.move()
        self.animation()
        self.wall_collision() # call this after the movement method to rectify the position of the player if he ran into a wall
        self.component_collision()
        self.wallet()
        self.score()
        self.lookup()
        self.reveal()
        self.new_bullet()
        
    def move(self):
        keylist = pygame.key.get_pressed() # generates a list of all keys with True if pressed and false otherwise
        
        if keylist[pygame.K_a]: # (Note, controls changed from LEFT to A,W,S,D) pygame.K_LEFT returns the index of the left key in the get_pressed Keylist, so this statement returns true if and only if the left key is pressed
            self.rect.x-=PLAYER_SPEED # when left is pressed, subtract the distance represented by PLAYER_SPEED from the x position of the player
            self.facing="left"
            self.moving=True
            for sprite in sprites:
                sprite.rect.x+=PLAYER_SPEED # to keep a centered camera angle, move all sprites in the opposite direction to which the player moved
            return # end the function here so that we don't get weird combinations of movements (e.g. left and up)
            
        if keylist[pygame.K_d]:
            self.rect.x+=PLAYER_SPEED
            self.facing="right"
            self.moving=True
            for sprite in sprites:
                sprite.rect.x-=PLAYER_SPEED
            return

        if keylist[pygame.K_w]:
            self.rect.y-=PLAYER_SPEED
            self.facing="up"
            self.moving=True
            for sprite in sprites:
                sprite.rect.y+=PLAYER_SPEED
            return

        if keylist[pygame.K_s]:
            self.rect.y+=PLAYER_SPEED
            self.facing="down"
            self.moving=True
            for sprite in sprites:
                sprite.rect.y-=PLAYER_SPEED
            return
        self.moving=False
    
    def animation(self):
        if self.facing=="left":
            if self.moving==False:
                self.pos=[48,48]
            else:
                position_list=[[0,48],[48,48],[96,48]]
                self.pos=position_list[int(self.count)]
                self.count+=0.1
                if self.count>=3: # doesn't work with self.count==3 because of something weird with floats having a small extra decimal component
                    self.count=0
                
        if self.facing=="right":
            if self.moving==False:
                self.pos=[48,96]
            else:
                position_list=[[0,96],[48,96],[96,96]]
                self.pos=position_list[int(self.count)]
                self.count+=0.1
                if self.count>=3:
                    self.count=0  
                    
        if self.facing=="up":
            if self.moving==False:
                self.pos=[48,144]
            else:
                position_list=[[0,144],[48,144],[96,144]]
                self.pos=position_list[int(self.count)]
                self.count+=0.1
                if self.count>=3:
                    self.count=0
                    
        if self.facing=="down":
            if self.moving==False:
                self.pos=[48,0]
            else:
                position_list=[[0,0],[48,0],[96,0]]
                self.pos=position_list[int(self.count)]
                self.count+=0.1
                if self.count>=3:
                    self.count=0                
         
        self.image=pygame.Surface([TILE_SIZE,TILE_SIZE])
        self.image.set_colorkey((0,0,0))
        self.image.blit(player_spritesheet,(0,0),(self.pos[0],self.pos[1],48,48))
        

            
    def wall_collision(self):
        # still not quite sure about the format of spritecollide() list
        hit_list = pygame.sprite.spritecollide(self,walls,False) # spritecollide() is an inherited method that checks whether one rectangle (i.e. player sprite itself) is inside another rectangle (i.e. wall sprite) and we include 'False' because we don't want to delete sprite along collision
        if hit_list: # True when a collision is taking place between the player and an element in the wall group of sprites
            if self.facing=="left":
                self.rect.x+=PLAYER_SPEED # undo the leftward movement by adding back PLAYER_SPEED
                for sprite in sprites:
                    sprite.rect.x-=PLAYER_SPEED # we don't want the camera to move everything if you collide with a block (we just want things to stay still so undo the previous change to all sprites' position)
            if self.facing=="right":
                self.rect.x-=PLAYER_SPEED
                for sprite in sprites:
                    sprite.rect.x+=PLAYER_SPEED
            if self.facing=="up":
                self.rect.y+=PLAYER_SPEED
                for sprite in sprites:
                    sprite.rect.y-=PLAYER_SPEED
            if self.facing=="down":
                self.rect.y-=PLAYER_SPEED
                for sprite in sprites:
                    sprite.rect.y+=PLAYER_SPEED
    
    def wallet(self):
        self.info=self.font.render(f"£{self.balance}",False,'Blue')
        screen.blit(self.info,(850,0))
        
    def score(self):
        self.info=self.font.render(f"{self.points} pts",False,'Blue')
        screen.blit(self.info,(400,0))
    
    def component_collision(self):
        hit_list = pygame.sprite.spritecollide(self,components,True)
        if hit_list:
            self.points+=hit_list[0].value
            self.balance-=hit_list[0].price
            self.basket+=[(hit_list[0].name,hit_list[0].price,hit_list[0].value)]
    
    def lookup(self):
        keylist = pygame.key.get_pressed() # I'm sure there is a more efficient way of checking if someone clicked enter
        if keylist[pygame.K_RETURN]:
            self.info=self.font.render(f"{self.basket}",False,'Blue')
            screen.blit(self.info,(0,600))
            
    def reveal(self):
        for sprite in components:
            if sprite.rect.collidepoint(pygame.mouse.get_pos()):
                self.info=self.font.render(f"{sprite.name},{sprite.price},{sprite.value}",False,'Blue')
                screen.blit(self.info,(sprite.x,sprite.y))
                #print((sprite.name,sprite.price,sprite.value))
    
    def new_bullet(self):
        keylist = pygame.key.get_pressed()
        if not keylist[pygame.K_SPACE]:
            self.trigger=0
 # I'm sure there is a more efficient way of checking if someone clicked enter
        if keylist[pygame.K_SPACE] and self.trigger==0:
            if self.facing=='up':
                Bullet(self.rect.x,self.rect.y,'up') # does this create multiple bullets since the space input is recorded many times
            elif self.facing=='down': # do the coordinates work with self.x or only self.rect.x, check with player position translation as well
                Bullet(self.rect.x,self.rect.y,'down') # does this create multiple bullets since the space input is recorded many times    
            elif self.facing=='left':
                Bullet(self.rect.x,self.rect.y,'left') # does this create multiple bullets since the space input is recorded many times                  
            elif self.facing=='right':
                Bullet(self.rect.x,self.rect.y,'right') # does this create multiple bullets since the space input is recorded many times                  
            self.trigger=1  
                
            #     if event.type==pygame.KEYDOWN:
            # if event.key==pygame.K_SPACE:
            #     Bullet(400,300,'up')
            
class Wall(pygame.sprite.Sprite):
    def __init__(self,x,y,style): # style is a variable that represents the type of wall e.g. 'A', 'B' 'C' etc. as shown on the game map
        super().__init__(sprites,walls) # make it a sprite and add a wall object to the sprites and walls groups
        # sprites.change_layer(self,WALL_LAYER)
        # walls.change_layer(self,WALL_LAYER)
        #self.layer=WALL_LAYER        
        
        self.width=TILE_SIZE
        self.height=TILE_SIZE
        self.x=TILE_SIZE*x
        self.y=TILE_SIZE*y
        
        self.style=style
        # Make sure that the image size is changed for images that are not square

        
        
        
        
        # elif self.style=='A': # Large computer table 1.1
        # # PUT THE GREY SHADOW BACK UNDER THESE TABLES TO MAKE THEM LOOK MORE REALISTIC
        #     self.image = pygame.Surface([TILE_SIZE*4,TILE_SIZE*2])
        #     self.image.set_colorkey((0,0,0))
        #     self.image.blit(object_spritesheet,(0,0),(0,0,256,128))
            
        self.image=pygame.Surface(SURFACES[self.style])
        self.image.set_colorkey((0,0,0))
        self.image.blit(object_spritesheet,(0,0),POSITIONS[self.style])
        
        self.rect = self.image.get_rect()
        self.rect.x=self.x
        self.rect.y=self.y

class Floor(pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__(sprites,floors) # make it a sprite and add a wall object to the sprites and walls groups
        # sprites.change_layer(self,FLOOR_LAYER)
        # floors.change_layer(self,FLOOR_LAYER)
          
        self.width=TILE_SIZE
        self.height=TILE_SIZE
        self.x=TILE_SIZE*x
        self.y=TILE_SIZE*y
        
        self.image=pygame.Surface([TILE_SIZE,TILE_SIZE])
        self.image.blit(object_spritesheet,(0,0),(576,512,64,64))
        
        self.rect=self.image.get_rect()
        self.rect.x=self.x
        self.rect.y=self.y
    
class Component(pygame.sprite.Sprite):
    def __init__(self,x,y,name,price,value):
        super().__init__(sprites,components)
        
        self.width=TILE_SIZE/2
        self.height=TILE_SIZE/2
        
        self.x=TILE_SIZE*x
        self.y=TILE_SIZE*y
        
        self.image=pygame.Surface([self.width,self.height])
        self.image.fill((255,0,0))
        
        self.rect=self.image.get_rect()
        self.rect.x=self.x
        self.rect.y=self.y
        
        self.name=name
        self.price=price
        self.value=value
        
class Bullet(pygame.sprite.Sprite):
    def __init__(self,x,y,direction):
        super().__init__(sprites,bullets)
        
        self.width=TILE_SIZE/4
        self.height=TILE_SIZE/4
        self.speed=1
        self.x=x
        self.y=y
        
        self.image=pygame.Surface([self.width,self.height])
        self.image.fill((0,255,0))
        
        self.rect=self.image.get_rect()
        self.rect.x=self.x
        self.rect.y=self.y
        
        self.direction=direction
    
    def update(self): # when you call sprite.update this calls ALL of the bullets so you don't need a loop since each bullet will get called anyway
        # you need to add code to delete bullets that go off the screen
        if self.direction=="up":
            self.rect.y-=self.speed
        if self.direction=="down":
            self.rect.y+=self.speed
        if self.direction=="left":
            self.rect.x-=self.speed
        if self.direction=="right":
            self.rect.x+=self.speed                