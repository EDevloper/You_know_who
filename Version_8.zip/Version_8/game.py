# -*- coding: utf-8 -*-
"""
Created on Sun Dec  5 16:56:27 2021

@author: jacob
"""

import pygame
import time
import sys
from random import *

from data import *
from sprites import *
from setup import *


class Game:
    def __init__(self):        

        
        # Initialising the timer
        self.time_limit=TIME_LIMIT # Sets the time limit for the game
        self.start_time=time.time() # Gets the current time in UNIX time
        self.elapsed_time=0
        self.remaining_time=self.time_limit
        
        # Initialising the type of screen being displayed
        self.slide="playing" # Ensures the game doesn't start up on the game over screen
    
    # Methods for performing specific actions
        
    def show_time(self): # This method will update the timer in each frame
        self.elapsed_time=time.time()-self.start_time # Finds the difference in UNIX time now versus upon starting the game 
        self.remaining_time=self.time_limit-int(self.elapsed_time) # We want a whole number of seconds to be displayed which is why 'elapsed time' is converted to an integer
        self.minutes=self.remaining_time//60 # Finds the whole number of minutes remaining
        self.seconds=self.remaining_time%60 # Finds the remainder from the previous line in seconds
        self.countdown=large_font.render(f"{self.minutes} min {self.seconds} sec",False,(0,0,255)) # Renders the time remaining in a textual format with anti-aliasing off and in a blue colour
        screen.blit(self.countdown,(0,0)) # Displays the time remaining in the top left of the screen
    
    def show_balance(self): # This method will update the monetary balance in each frame
        self.info=large_font.render(f"£{self.p.balance}",False,(0,0,255)) # Render the player's balance
        screen.blit(self.info,(850,0)) # Print it onto the screen
        
    def show_score(self):
        self.info=large_font.render(f"{self.p.points} pts",False,(0,0,255))
        screen.blit(self.info,(440,0))
    
    
    def gamemap(self): # This method will render the full game map, including items, walls, players, and floors
        for row in range(0,len(GAMEMAP)): # Note that the first and last rows and columns in the game map are reserved for the (literal) walls
            for column in range(0,len(GAMEMAP[row])):
                if row not in [0,len(GAMEMAP)-1] and column not in [0,len(GAMEMAP[row])-1]: # Since we are using transparency, we do not want floor tiles to spill over the edges of the map
                    Floor(column-X_SHIFT,row-Y_SHIFT) # There are no interactions involving floors, so there is no harm in rendering floor on game tiles underneath the other objects
                if GAMEMAP[row][column]=="A": # Larger objects occupy multiple tiles, so this line is necessary to prevent PC components from spawning on top of them
                    pass

                elif GAMEMAP[row][column]=="E":
                    Enemy(column - X_SHIFT, row - Y_SHIFT)
                elif GAMEMAP[row][column]=="E3":
                    Enemy3(column - X_SHIFT, row - Y_SHIFT)
                elif GAMEMAP[row][column]!=".": # This conditional will evaluate as true when objects needs to be placed on a tile (represented by an integer in the game map)
                    index=GAMEMAP[row][column] # Records the number displayed in tile (row,column) on the game map
                    Wall(column-SHIFTS[index][0],row-SHIFTS[index][1],index) # Generates a 'wall' sprite of the correct type in tile (row,column) - note that the shifts are needed so that pygame initially displays the correct part of the map

                else:
                    chance=randint(1,COMPONENT_RARITY)
                    if chance==1: # For every empty tile, we randomly generate a number, and if that number is one, we place a PC component in that tile
                        variety=list(CATALOGUE.keys())[randint(0,9)] # Randomly selects a type of component to go into the chosen tile
                        tier=randint(0, len(list(CATALOGUE.values())[0][0])-1) # Randomly selects the level of the component, ranging from 'budget' to 'elite'
                        lb_price=CATALOGUE[variety][1][tier][0] # These lines will store the upper and lower bounds of price and points for a component of the given variety and tier
                        ub_price=CATALOGUE[variety][1][tier][1]
                        lb_points=CATALOGUE[variety][2][tier][0]
                        ub_points=CATALOGUE[variety][2][tier][1]
                        Component(column-X_SHIFT,row-Y_SHIFT,variety,CATALOGUE[variety][0][tier],randint(lb_price,ub_price),randint(lb_points,ub_points)) # Generate a component with price and points randomly between the upper and lower bounds
                if GAMEMAP[row][column] in CHECKOUTS:
                    Checkout(column-X_SHIFT,row-Y_SHIFT) # The checkout till will already be created as a sprite of 'Wall' class, but we want to overlay an invisible sprite of 'Checkout' class in order to give extra functionality
        self.p=Player(PLAYER_X,PLAYER_Y) # Spawn the player in a predetermined location and store the player sprite under the attribute 'p' so that the player data can be easily accessed later
        #self.i= ItemBox('Health', 500, 200)

    def reset(self): # This method will empty all the sprite groups, reset the timer, and then repopulate the game map and hence recreate all sprites in their original positions
        self.slide="playing" # Switch to the 'playing' state (so that the new game runs)
        sprites.empty() # Emptying out all sprite groups so that there is no lingering data when we reset the game
        walls.empty()
        floors.empty()
        characters.empty()
        components.empty()
        bullets.empty()
        chests.empty()
        checkouts.empty()
        explosion_group.empty()
        grenade_group.empty()
        ItemBox_group.empty()
        self.start_time=time.time() # By resetting the start time, when we call 'show_time', 'elapsed time' will go back to zero and 'remaining time' will go back to 'time limit'
        self.show_time() # We need to call this here so that 'remaining time' gets reset to 'time limit' (otherwise 'remaining time' stays as 0 and the new game immediately ends)
        self.gamemap() # Generate the new game map along with the new player

        
      
    # Methods for controlling the game loop while playing the game

    def event_loop_playing(self): # This method will trigger the event loop every frame when we are playing the game
        for event in pygame.event.get(): # This is the 'event loop': checks through all the pygame events
            if event.type==pygame.KEYDOWN: # We use the event loop to check for key presses where we need to detect a unique press in a stream of frames
                if event.key==pygame.K_RETURN and not self.p.till: # Provided that the player is not at the checkout, the 'enter' key should toggle the basket menu off and on
                    pygame.mixer.find_channel(True).play(select2_music)
                    self.p.show= not self.p.show
                if self.p.show: # This conditional is used for navigating the basket - we want up and down arrow clicks to only be detected once
                    if event.key==pygame.K_DOWN and self.p.selection<len(self.p.basket)-1:
                        self.p.selection+=1 # 'selection' is an attribute of the player class that records which PC component you may wish to remove from the basket
                    if event.key==pygame.K_UP and self.p.selection>0: # We change this attribute depending on how you navigate the basket
                        self.p.selection-=1
                    if event.key==pygame.K_BACKSPACE: # When you try to remove items from the trolley, we also want this to be recorded only once, which is why we are using the event loop
                        pygame.mixer.find_channel(True).play(delete_music)
                        self.p.deletion=True

                        
                if self.p.till: # This conditional is used for navigating the checkout screen - we want left and right arrow clicks to only be detected once
                    if event.key==pygame.K_LEFT and not self.p.finished: # 'finished' is an attribute of the player class that is recording on the checkout screen whether or not you wish to finish 
                        self.p.finished=True # The player can control whether or not they wish to finish by using the left and right arrows
                    if event.key==pygame.K_RIGHT and self.p.finished:
                        self.p.finished=False
                    if event.key==pygame.K_SPACE: # Space bar is used to show the checkout menu if you are at the till
                        self.p.show=True # We want the player to be able to toggle this menu on and off with a click of the space bar, which is why we need to record unique clicks and hence use the event loop
                        
            if event.type == pygame.QUIT: # Returns true if you click the exit button
                pygame.quit() # The opposite to pygame.init(), closes the pygame engine
                sys.exit() # A method from the 'sys' library - securely breaks out of both the event and game loops            
                
    def playing_refresh(self): # This method will run every frame when we are playing the game
        screen.fill((0,0,0)) # For each frame, first reset to an empty black screen so images from the previous frame don't linger
        floors.draw(screen) # The draw methods will look for the image and rect (i.e. position) for the sprites in each of the following groups and draw these onto the screen
        walls.draw(screen) # The order in which the draw methods are called is carefully chosen so that the images are layered on top of each other in the right order
        components.draw(screen)
        chests.draw(screen)
        characters.draw(screen)
        bullets.draw(screen)
        #weapon
        bullet_group.draw((screen))
        grenade_group.draw(screen)
        explosion_group.draw(screen)
        slash_group.draw(screen)
        enemies.draw(screen)

        #itembox
        ItemBox_group.draw((screen))

        sprites.update() # This 'update' method will call the 'update' methods listed under each class of sprite - we call sprites.update() last because it contains text rendering that needs to be displayed last in each frame
        self.show_time() # This updates the timer
        self.show_balance() # This updates the balance
        self.show_score() # Updates the score counter

    # Methods for controlling the game loop while on the game over screen

    def event_loop_endscreen(self): # This method will trigger the event loop for every frame we are in the game over screen
        for event in pygame.event.get():
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_n: # Checks if the player is pressing down 'n' (to start a new game)
                    self.reset() # Creates a new game
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                
    def endscreen_refresh(self): # This method will run every frame when we are in the game over screen
        screen.fill((0,0,0)) # For each frame, first reset to an empty black screen so images from the previous frame don't linger
        if int(self.remaining_time)==0: # Print one of two game over messages, either from running out of time or exiting the level from the checkout desk
            self.result=large_font.render(f"Your score is 0 because you ran out of time",False,(0,0,255))
        elif self.p.alive==False:
            self.result = large_font.render(f"Your score is 0 because you died", False, (0, 0, 255))
        else:
            self.result=large_font.render(f"Your score is {self.p.points}",False,(0,0,255))
        screen.blit(self.result,(0,0))  # Print game over message in top left of the pygame screen        

