# -*- coding: utf-8 -*-
"""
Created on Wed Dec  1 22:27:10 2021

@author: jacob
"""

# Reference: https://www.youtube.com/watch?v=crUF36OkGDw&ab_channel=ShawCode
# used as inspiration for setting up the game map and core movement mechanics

# Reference: https://www.youtube.com/watch?v=AY9MnQ4x3zk&ab_channel=ClearCode
# used for initialising game screen and quitting

# https://www.youtube.com/watch?v=hDu8mcAlY4E&ab_channel=ClearCode
# For understanding sprites

# main shop inspired by curry's pc world
# If the player tries to enter the front door, you should be taken back to the main menu (like leaving a pokemon center)
# the front door is also inspired by pokemon pearl doors
# See if you can use regular sprite groups rather than layered updates

# Would be pretty cool to have a rug/a few types of carpets leading from the goblins at the start of the map

# You might need a few more dead ends in the map (although part of the challenge is also finding the pc component)

# for each level, spawn a poor quality, mid tier, and top tier pc component

"""
Make sure that you look at the project specification on moodle again to make sure you are doing it right

Note that you can use lots of empty shelves and cupboards to represent the lack of stock in the computer shop

Note that your donut stands are the wrong size

USE GAME CONSOLE IMAGES FROM THE PIXEL GRAPHICS AND INSERT ONTO TABLES TO CREATE GAME CONSOLE DISPLAYS


ADD a carpet leading from the gnomes at the start of the map


If we don't have time to design different levels, we could just have
one big level with lots of components scattered around and you have
to get as many components and score as many points as possible

Then you take all the items you found to the checkout and your score
is totalled there.

Perhaps the location of components can be randomised so there is
difference in the gameplay each time you play


THERE are a few places where you haven't chosen the correct surface shape
so you can't walk past as seamlessly as you should - go over and fix the surface dimensions


New gameplay idea/storyline: There are massive shortages of electronic items due to pandemic supply chain issues,
You want to build a new gaming pc, you get there right when the shops open to maximise your chances of finding what you're looking for
But to prevent people from stockpiling, everyone is only allowed 5 minutes in the shop before they are booted out.

You also have a maximum budget of £2000 to build your pc with.

There are various components scattered around the map that cost different amounts, so you have to be selective about what you pick up

You need to choose your components within these 5 minutes you have in the shop and reach the checkout at the end of the map.

There can be an interesting dialogue at the checkout where your score is revealed step by step like in fruit ninja

If time runs out, you score zero, the game freezes and a security guard walks up and kicks you out of the shop empty handed

If you die, a pokemon like black out message appears on the screen, you drop all your items and return to the start of the map empty handed

Note that the scoring system can penalise you if you only buy one type of component (e.g. only graphics cards)

# Should the timer be a method under the player class too?


You have to acknowledge materials you used from the internet and explain what you did differently

They only mark you on the new material you have created

# Learn how to use JSON for storing the data

Change 'blue' to (0,255,0) since the name doesn't work on other people's computers
"""

import pygame # load pygame library
import sys # useful

from data import * # import values of variables set in data.py
from sprites import * # import our game classes from classes.py
from elements import *

        
    
pygame.init() # starts the pygame engine
screen=pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT)) # creates the screen that our game will be displayed on
pygame.display.set_caption('You Know Who') # displays the title of our game
clock=pygame.time.Clock()



# I think layered updates might be a special type of pygame.sprite.Group() that allows you to assign various layers
# Perhaps you can just call pygame.sprite.Group() instead?



# for i, row in enumerate(GAMEMAP):
#     for j, column in enumerate(row):
#         if column == "A":
#             Wall(j,i)
#         if column == "P":
#             Player(j,i)


# object_spritesheet=pygame.image.load("graphics/objects.png").convert() 
# # Note that the pygame window starts from (0,0)
# # so we have to shift x and y coordinates to get the right position
# image=pygame.Surface([TILE_SIZE,TILE_SIZE])

# image.blit(object_spritesheet,(0,0),(128,0,64,64))

g=Gamemap() # generate an object of class gamemap
t=Timer()

while True: # Keep game running forever until we exit this loop: this is the 'game loop'
    for event in pygame.event.get(): # the 'event loop': checks through all the pygame events
        if event.type == pygame.QUIT: # if you click the exit button
            pygame.quit() # the opposite to pygame.init(), closes the pygame engine
            sys.exit() # method from the 'sys' library - securely breaks out of both the for and while loops (not sure why a double 'break' statement fails?) (apparantly more secure than 'break')

    screen.fill((0,0,0))
    floors.draw(screen) # this will look for the image and rect (i.e. position) in all of our sprites and draw these onto the screen
    walls.draw(screen)
    components.draw(screen)
    characters.draw(screen)
    bullets.draw(screen)
    t.display()
    sprites.update() # this will look for the 'update' method in all the sprites that we have defined and run it
    pygame.display.update() # refresh the screen so that changes are visually displayed
    clock.tick(FPS) # tells pygame that game should not run faster than 60 FPS, a minimum frame rate is not needed because almost all modern computers can handle basic games at 60 FPS