#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Suno Dec 12 18:22:29 2021

@author: jawadnadeem
"""
import pickle
ls=["Name","Name","Name","Name","Name","Name","Name","Name","Name","Name"]
pickle.dump(ls,open("names.p","wb"))

# ls2=pickle.load(open("scores.p","rb"))

# ls2[0]=1
# pickle.dump(ls2,open("scores.p","wb"))
# ls3=pickle.load(open("scores.p","rb"))
# ls3[1]=2
# print(ls3)


# hn=['K', 0, 'Eddie','Bruce']
# pickle.dump(hn,open("names.p","wb"))

# hn2=pickle.load(open("names.p","rb"))

# hn2[1]='Leo'
# print(hn2)

