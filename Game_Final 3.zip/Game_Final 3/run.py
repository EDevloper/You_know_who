# -*- coding: utf-8 -*-
"""
Created on Wed Dec  1 22:27:10 2021

@author: jacob
"""

# Reference: https://www.youtube.com/watch?v=crUF36OkGDw&ab_channel=ShawCode
# used as inspiration for setting up the game map and core movement mechanics and having a game class

# Reference: https://www.youtube.com/watch?v=AY9MnQ4x3zk&ab_channel=ClearCode
# used for initialising game screen and quitting

# https://www.youtube.com/watch?v=hDu8mcAlY4E&ab_channel=ClearCode
# For understanding sprites

# https://stock.adobe.com/uk/search?load_type=search&native_visual_search=&similar_content_id=&is_recent_search=&search_type=usertyped&k=PC+components+pixel+art+vector+set.&asset_id=187488698&continue-checkout=1
# Downloaded license for component pics here

#https://www.youtube.com/watch?v=aQJCLfEmSs4&ab_channel=CodingWithRuss
# Inspiration for resetting the game

# main shop inspired by curry's pc world
# If the player tries to enter the front door, you should be taken back to the main menu (like leaving a pokemon center)
# the front door is also inspired by pokemon pearl doors
# See if you can use regular sprite groups rather than layered updates

# Would be pretty cool to have a rug/a few types of carpets leading from the goblins at the start of the map

# You might need a few more dead ends in the map (although part of the challenge is also finding the pc component)

# for each level, spawn a poor quality, mid tier, and top tier pc component

"""
Make sure that you look at the project specification on moodle again to make sure you are doing it right

Note that you can use lots of empty shelves and cupboards to represent the lack of stock in the computer shop

Note that your donut stands are the wrong size

USE GAME CONSOLE IMAGES FROM THE PIXEL GRAPHICS AND INSERT ONTO TABLES TO CREATE GAME CONSOLE DISPLAYS


ADD a carpet leading from the gnomes at the start of the map


If we don't have time to design different levels, we could just have
one big level with lots of components scattered around and you have
to get as many components and score as many points as possible

Then you take all the items you found to the checkout and your score
is totalled there.

Perhaps the location of components can be randomised so there is
difference in the gameplay each time you play


THERE are a few places where you haven't chosen the correct surface shape
so you can't walk past as seamlessly as you should - go over and fix the surface dimensions


New gameplay idea/storyline: There are massive shortages of electronic items due to pandemic supply chain issues,
You want to build a new gaming pc, you get there right when the shops open to maximise your chances of finding what you're looking for
But to prevent people from stockpiling, everyone is only allowed 5 minutes in the shop before they are booted out.

You also have a maximum budget of £2000 to build your pc with.

There are various components scattered around the map that cost different amounts, so you have to be selective about what you pick up

You need to choose your components within these 5 minutes you have in the shop and reach the checkout at the end of the map.

There can be an interesting dialogue at the checkout where your score is revealed step by step like in fruit ninja

If time runs out, you score zero, the game freezes and a security guard walks up and kicks you out of the shop empty handed

If you die, a pokemon like black out message appears on the screen, you drop all your items and return to the start of the map empty handed

Note that the scoring system can penalise you if you only buy one type of component (e.g. only graphics cards)

# Should the timer be a method under the player class too?


You have to acknowledge materials you used from the internet and explain what you did differently

They only mark you on the new material you have created

# Learn how to use JSON for storing the data

Change 'blue' to (0,255,0) since the name doesn't work on other people's computers

You need to get the image and audio sources from Tony

Look at how you can use child classes and inheritance in the code!!!

if x=True you don't need to write if x==True:, you can just write if x: - fix this


ADD AS MANY DATA POINTS TO DATA.PY as possible (inc. text messages), make code as generalisable as possible

ADD SOUNDS

HAVE A LIMIT ON THE NUMBER OF ITEMS PLAYER CAN HAVE IN THEIR BAG

DON'T ALLOW PLAYER TO SPEND MORE MONEY THAN THEY HAVE

EXPLAIN THE ROLE OF EACH PYTHON FILE AND HOW THEY ALL FEED INTO ONE ANOTHER

THERE CAN BE BONUSES (E.g. if you collect all types of components) and PENALTIES (e.g. if you have multiple copies of the same component)

Add error message if bag is full


Generalise player position again on the map

Storyline:
    
Due to the Covid-19 pandemic, we have seen an unfortunate shortage in computer chips, graphics cards, gaming consoles, and other PC components.

This is due to the extreme cost and time it takes to both produce these components and to build new plants, as well as due to resellers buying up all the stock and scalping consumers.

Your goal is to build a brand new gaming PC, which will be a big challenge considering these circumstances.

You will spawn at the entrance of a massive computer shop and you need to purchase the components with which you will build your PC.

However, to discourage bulk buying, there is a 5 minute time limit inside the shop.

If you have not successfully bought your items at the checkout by this time, you will be booted out of the shop empty handed.

And as you can imagine, you are also not the only one shopping for these scarce components.

You will encounter many enemies on your journey throughout the shop who will try to beat you up and grab the components in your basket.

Good luck with your shopping, and happy PC building!
    
"""


from game import * # In this python file, we only directly communicate with an object of 'Game' method

g=Game() # Generate an object of class 'Game'
g.gamemap() # Use the 'gamemap' method to fully populate the initial game map



while True: # This is called the 'game loop': it keeps the game running forever until we exit this loop 

    if g.remaining_time==0 or g.p.end: # These are the two scenarios where the game needs to end (either you ran out of time or you completed the level)
        g.slide="endscreen" # When the game ends, we want to go to the 'endscreen'
        
        # for event in pygame.event.get():
        #     if event.type==pygame.KEYDOWN:
        #         if event.key==pygame.K_RETURN:
        #             g.slide="menu"
                    
    
    if g.slide=="menu":
        g.event_loop_menu()
        g.menu_refresh()
        
        
    if g.slide=="playing": # This conditional statement will run the main game
        g.event_loop_playing() # This 'Game' method will run the event loop for the main game
        g.playing_refresh() # This 'Game' method will run the rest of the code for the main game inside the game loop
        
    if g.slide=="settings":
        g.event_loop_settings()
        g.settings_refresh()
    
    if g.slide=="leaderboard":
        g.event_loop_leaderboard()
        g.leaderboard_refresh()
    
    if g.slide=="endscreen": # This conditional statement will run the game over screens
        g.event_loop_endscreen() # This 'Game' method will run the event loop for the game over screens
        g.endscreen_refresh() # This 'Game' method will run the rest of the code for the game over screens inside the game loop
        
        
    
            
        
    pygame.display.update() # This function will update the pygame display every frame
    clock.tick(FPS) # Sets the frame rate of the game (60FPS in this case)