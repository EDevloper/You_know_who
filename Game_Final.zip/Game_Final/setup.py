# -*- coding: utf-8 -*-
"""
Created on Tue Dec  7 23:00:25 2021

@author: jacob
"""

import pygame

from data import *

# Initialising pygame (needed here for initialising fonts and will be used throughout the other python files that import 'setup')

pygame.init()
pygame.display.set_caption('You Know Who') # Displays the game title
clock=pygame.time.Clock() # Necessary for the basic set up of the frame rate
screen=pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT)) # Sets up the pygame display that allows us to load images and print them onto the screen

# Loading images

player_spritesheet=pygame.image.load("graphics/main.png").convert() # Load player spritesheet and use convert() to import more efficiently
player_spritesheet=pygame.transform.scale(player_spritesheet,(144,192)) # This will enlarge the player spritesheet by a factor of 1.5 (this size provides a balance between readability and mobility)
object_spritesheet=pygame.image.load("graphics/objects.png").convert() # Load sheet containing walls and furniture
component_spritesheet=pygame.image.load("graphics/components.png").convert() # Load sheet containing PC components that will be randomly scattered around the map

# Loading fonts - initialises the font style that will be used in this game (in three different sizes)

medium_font=pygame.font.Font("font/Exo-Bold.ttf",FONT_SIZE[1])
small_font=pygame.font.Font("font/Exo-Bold.ttf",FONT_SIZE[0])
large_font=pygame.font.Font("font/Exo-Bold.ttf",FONT_SIZE[2])

# Initialising sprite groups

sprites=pygame.sprite.Group() # This group is the union of all below groups (contains all sprites)
walls=pygame.sprite.Group()
floors=pygame.sprite.Group()
characters=pygame.sprite.Group()
components=pygame.sprite.Group()
bullets=pygame.sprite.Group()
chests=pygame.sprite.Group()
checkouts=pygame.sprite.Group()