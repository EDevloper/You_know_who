# -*- coding: utf-8 -*-
"""
Created on Wed Dec  1 22:29:26 2021

@author: jacob
"""

import pygame

from data import *
from core import *

class Player(pygame.sprite.Sprite): # inherit from the sprite class to make our main character a sprite
    def __init__(self,x,y):
        self.layer=PLAYER_LAYER
        pygame.sprite.Sprite.__init__(self,sprites) # add the player sprite to the group of all sprites so that the player can be updated and drawn correctly
        
        self.width=TILE_SIZE # we want the player to be exactly one 48 pixel tile squared in size
        self.height=TILE_SIZE
        self.x=TILE_SIZE*x # we want to measure the x and y coordinates in tiles not in pixels, so we need to modify our x in tiles to represent pixels correctly
        self.y=TILE_SIZE*y
        
        
        # Size and visual of player
        self.image=pygame.Surface([self.width,self.height])
        self.image.fill((255,0,0))
        
        # Position of player
        self.rect=self.image.get_rect()
        self.rect.x=self.x
        self.rect.y=self.y
    
                    
        