# -*- coding: utf-8 -*-
"""
Created on Wed Dec  1 22:27:10 2021

@author: jacob
"""

# Reference: https://www.youtube.com/watch?v=crUF36OkGDw&ab_channel=ShawCode
# used as inspiration for setting up the game map and core movement mechanics

# Reference: https://www.youtube.com/watch?v=AY9MnQ4x3zk&ab_channel=ClearCode
# used for initialising game screen and quitting

# https://www.youtube.com/watch?v=hDu8mcAlY4E&ab_channel=ClearCode
# For understanding sprites


# See if you can use regular sprite groups rather than layered updates

"""
Make sure that you look at the project specification on moodle again to make sure you are doing it right
"""

import pygame # load pygame library
import sys # useful

from data import * # import values of variables set in data.py
# from classes import * # import our game classes from classes.py

class Player(pygame.sprite.Sprite): # inherit from the sprite class to make our main character a sprite
    def __init__(self,x,y):
        super().__init__(sprites) # makes player class a sprite and adds it to the sprites list
        sprites.change_layer(self,PLAYER_LAYER) # sets the layer of the player class
        #pygame.sprite.Sprite.__init__(self,sprites) # add the player sprite to the group of all sprites so that the player can be updated and drawn correctly
        
        self.width=TILE_SIZE # we want the player to be exactly one 48 pixel tile squared in size
        self.height=TILE_SIZE
        self.x=TILE_SIZE*x # we want to measure the x and y coordinates in tiles not in pixels, so we need to modify our x in tiles to represent pixels correctly
        self.y=TILE_SIZE*y
        
        # note that you HAVE to call your surface 'image' for the 'blit' method to recognise what you are trying to do
        
        self.facing="down"
        self.pos=[64,0]
        self.count=0
        
        self.image=pygame.Surface([TILE_SIZE,TILE_SIZE]) # create a blank surface with area equal to TILE_SIZE
        self.image.set_colorkey((0,0,0)) # make any pixels in the player picture that are pure black
        self.image.blit(player_spritesheet,(0,0),(self.pos[0],self.pos[1],64,64)) # Not quite sure why you need to pass (0,0) here?
        # I think you need to pass (0,0) to tell 'blit' that you want to start reading player_spritesheet from the top left, 
        
        # # Size and visual of player
        # self.image=pygame.Surface([self.width,self.height])
        # self.image.fill((255,0,0))
        
        # Position of player
        self.rect=self.image.get_rect()
        self.rect.x=self.x # insert x and y as rect attributes so that they can be easily accessed and used in rect methods
        self.rect.y=self.y
        
        
        
        
    def update(self): # This update method will run when we call the sprites.update() in the main program
        self.move()
        self.animation()
        self.wall_collision() # call this after the movement method to rectify the position of the player if he ran into a wall

        
    def move(self):
        keylist = pygame.key.get_pressed() # generates a list of all keys with True if pressed and false otherwise
        
        if keylist[pygame.K_a]: # (Note, controls changed from LEFT to A,W,S,D) pygame.K_LEFT returns the index of the left key in the get_pressed Keylist, so this statement returns true if and only if the left key is pressed
            self.rect.x-=PLAYER_SPEED # when left is pressed, subtract the distance represented by PLAYER_SPEED from the x position of the player
            self.facing="left"
            self.moving=True
            for sprite in sprites:
                sprite.rect.x+=PLAYER_SPEED # to keep a centered camera angle, move all sprites in the opposite direction to which the player moved
            return # end the function here so that we don't get weird combinations of movements (e.g. left and up)
            
        if keylist[pygame.K_d]:
            self.rect.x+=PLAYER_SPEED
            self.facing="right"
            self.moving=True
            for sprite in sprites:
                sprite.rect.x-=PLAYER_SPEED
            return

        if keylist[pygame.K_w]:
            self.rect.y-=PLAYER_SPEED
            self.facing="up"
            self.moving=True
            for sprite in sprites:
                sprite.rect.y+=PLAYER_SPEED
            return

        if keylist[pygame.K_s]:
            self.rect.y+=PLAYER_SPEED
            self.facing="down"
            self.moving=True
            for sprite in sprites:
                sprite.rect.y-=PLAYER_SPEED
            return
        self.moving=False
    
    def animation(self):
        if self.facing=="left":
            if self.moving==False:
                self.pos=[64,64]
            else:
                position_list=[[0,64],[64,64],[128,64]]
                self.pos=position_list[int(self.count)]
                self.count+=0.1
                if self.count>=3: # doesn't work with self.count==3 because of something weird with floats having a small extra decimal component
                    self.count=0
                
        if self.facing=="right":
            if self.moving==False:
                self.pos=[64,128]
            else:
                position_list=[[0,128],[64,128],[128,128]]
                self.pos=position_list[int(self.count)]
                self.count+=0.1
                if self.count>=3:
                    self.count=0  
                    
        if self.facing=="up":
            if self.moving==False:
                self.pos=[64,192]
            else:
                position_list=[[0,192],[64,192],[128,192]]
                self.pos=position_list[int(self.count)]
                self.count+=0.1
                if self.count>=3:
                    self.count=0
                    
        if self.facing=="down":
            if self.moving==False:
                self.pos=[64,0]
            else:
                position_list=[[0,0],[64,0],[128,0]]
                self.pos=position_list[int(self.count)]
                self.count+=0.1
                if self.count>=3:
                    self.count=0                
         
        self.image=pygame.Surface([TILE_SIZE,TILE_SIZE])
        self.image.set_colorkey((0,0,0))
        self.image.blit(player_spritesheet,(0,0),(self.pos[0],self.pos[1],64,64))
        

            
    def wall_collision(self):
        # still not quite sure about the format of spritecollide() list
        hit_list = pygame.sprite.spritecollide(self,walls,False) # spritecollide() is an inherited method that checks whether one rectangle (i.e. player sprite itself) is inside another rectangle (i.e. wall sprite) and we include 'False' because we don't want to delete sprite along collision
        if hit_list: # True when a collision is taking place between the player and an element in the wall group of sprites
            if self.facing=="left":
                self.rect.x+=PLAYER_SPEED # undo the leftward movement by adding back PLAYER_SPEED
                for sprite in sprites:
                    sprite.rect.x-=PLAYER_SPEED # we don't want the camera to move everything if you collide with a block (we just want things to stay still so undo the previous change to all sprites' position)
            if self.facing=="right":
                self.rect.x-=PLAYER_SPEED
                for sprite in sprites:
                    sprite.rect.x+=PLAYER_SPEED
            if self.facing=="up":
                self.rect.y+=PLAYER_SPEED
                for sprite in sprites:
                    sprite.rect.y-=PLAYER_SPEED
            if self.facing=="down":
                self.rect.y-=PLAYER_SPEED
                for sprite in sprites:
                    sprite.rect.y+=PLAYER_SPEED
        
class Wall(pygame.sprite.Sprite):
    def __init__(self,x,y,style): # style is a variable that represents the type of wall e.g. 'A', 'B' 'C' etc. as shown on the game map
        super().__init__(sprites,walls) # make it a sprite and add a wall object to the sprites and walls groups
        sprites.change_layer(self,WALL_LAYER)
        walls.change_layer(self,WALL_LAYER)
        #self.layer=WALL_LAYER        
        
        self.width=TILE_SIZE
        self.height=TILE_SIZE
        self.x=TILE_SIZE*x
        self.y=TILE_SIZE*y
        
        self.style=style
        
        if self.style=='a':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.blit(floor_spritesheet,(0,0),(0,0,64,64))
        if self.style=='b':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.blit(floor_spritesheet,(0,0),(64,0,64,64))        
        if self.style=='c':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.blit(floor_spritesheet,(0,0),(0,64,64,64))
        if self.style=='d':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.blit(floor_spritesheet,(0,0),(128,0,64,64))
        if self.style=='e':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.blit(floor_spritesheet,(0,0),(0,128,64,64))
        if self.style=='f':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.blit(floor_spritesheet,(0,0),(128,64,64,64))        
        if self.style=='g':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.blit(floor_spritesheet,(0,0),(64,128,64,64))
        if self.style=='h':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.blit(floor_spritesheet,(0,0),(128,128,64,64)) 
        
        if self.style=='A':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.set_colorkey((0,0,0))
            self.image.blit(counter_spritesheet,(0,0),(2,0,64,64))
        if self.style=='B':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.set_colorkey((0,0,0))
            self.image.blit(counter_spritesheet,(0,0),(66,0,64,64))
        if self.style=='C':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.set_colorkey((0,0,0))
            self.image.blit(counter_spritesheet,(0,0),(110,263,40,50))
        if self.style=='D':
            self.image = pygame.Surface([TILE_SIZE,TILE_SIZE])
            self.image.set_colorkey((0,0,0))
            self.image.blit(counter_spritesheet,(0,0),(310,186,40,50))            
     
        
        self.rect = self.image.get_rect()
        self.rect.x=self.x
        self.rect.y=self.y

class Floor(pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__(sprites,floors) # make it a sprite and add a wall object to the sprites and walls groups
        sprites.change_layer(self,FLOOR_LAYER)
        floors.change_layer(self,FLOOR_LAYER)
          
        self.width=TILE_SIZE
        self.height=TILE_SIZE
        self.x=TILE_SIZE*x
        self.y=TILE_SIZE*y
        
        self.image=pygame.Surface([TILE_SIZE,TILE_SIZE])
        self.image.blit(floor_spritesheet,(0,0),(64,64,64,64))
        
        self.rect=self.image.get_rect()
        self.rect.x=self.x
        self.rect.y=self.y
        
    
pygame.init() # starts the pygame engine
screen=pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT)) # creates the screen that our game will be displayed on
pygame.display.set_caption('You Know Who') # displays the title of our game
clock=pygame.time.Clock()

player_spritesheet=pygame.image.load("graphics/main.png").convert() # load player spritesheet and use convert() to import more efficiently
player_spritesheet=pygame.transform.scale(player_spritesheet,(192,256)) # make it 64 by 64 pixels rather than 32 by 32

floor_spritesheet=pygame.image.load("graphics/floors.png").convert()



counter_spritesheet=pygame.image.load("graphics/counter.png").convert()
counter_spritesheet=pygame.transform.scale(counter_spritesheet,(350,350))



sprites=pygame.sprite.LayeredUpdates() # Not quite sure about this, but apparantly allows us to have one group of sprites with different layer attrtibutes that we can update all at once
walls=pygame.sprite.LayeredUpdates() # Again, not quite sure, but this should allow us to store all our wall objects in a separate group
floors=pygame.sprite.LayeredUpdates()

# I think layered updates might be a special type of pygame.sprite.Group() that allows you to assign various layers
# Perhaps you can just call pygame.sprite.Group() instead?



# for i, row in enumerate(GAMEMAP):
#     for j, column in enumerate(row):
#         if column == "A":
#             Wall(j,i)
#         if column == "P":
#             Player(j,i)


    


for row in range(len(GAMEMAP)):
    for column in range(len(GAMEMAP[row])):
        Floor(column,row)
        if GAMEMAP[row][column]=="A":
            Wall(column,row,"A")
        elif GAMEMAP[row][column]=="B":
            Wall(column,row,"B")
        elif GAMEMAP[row][column]=="C":
            Wall(column,row,"C")
        elif GAMEMAP[row][column]=="D":
            Wall(column,row,"D")
        elif GAMEMAP[row][column]=="P":
            Player(column,row)

Wall(0,0,"a")
Wall(len(GAMEMAP)-1,0,"d")
Wall(0,len(GAMEMAP)-1,"e")
Wall(len(GAMEMAP)-1,len(GAMEMAP)-1,"h")
for i in range(1,len(GAMEMAP)-1):
    Wall(i,0,'b')
    Wall(0,i,'c')
    Wall(i,len(GAMEMAP)-1,'g')
    Wall(len(GAMEMAP)-1,i,'f')  

while True: # Keep game running forever until we exit this loop: this is the 'game loop'
    for event in pygame.event.get(): # the 'event loop': checks through all the pygame events
        if event.type == pygame.QUIT: # if you click the exit button
            pygame.quit() # the opposite to pygame.init(), closes the pygame engine
            sys.exit() # method from the 'sys' library - securely breaks out of both the for and while loops (not sure why a double 'break' statement fails?) (apparantly more secure than 'break')
    
    sprites.update() # this will look for the 'update' method in all the sprites that we have defined and run it
    screen.fill((0,0,0))
    sprites.draw(screen) # this will look for the image and rect (i.e. position) in all of our sprites and draw these onto the screen
    pygame.display.update() # refresh the screen so that changes are visually displayed
    clock.tick(FPS) # tells pygame that game should not run faster than 60 FPS, a minimum frame rate is not needed because almost all modern computers can handle basic games at 60 FPS